﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-LMGD5FU\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}