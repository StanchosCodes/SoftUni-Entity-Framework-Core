﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-LMGD5FU\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
