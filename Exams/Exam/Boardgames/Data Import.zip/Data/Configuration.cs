﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-LMGD5FU\SQLEXPRESS;Database=BoardgamesExam;Integrated Security=True;Encrypt=False";
    }
}
